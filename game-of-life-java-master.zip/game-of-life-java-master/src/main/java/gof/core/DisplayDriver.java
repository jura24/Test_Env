package gof.core;

public interface DisplayDriver {
    void displayBoard(Board board);
}
